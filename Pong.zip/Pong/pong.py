'''
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see <http://www.gnu.org/licenses/>.
#####
Hanzala N. Siddiqui
Pong
Version 2.0
'''


import pygame
import sys
import time

background = (0, 0, 0)
entity_color = (255, 255, 255)
font_name = pygame.font.match_font("arial")
def draw_text(surf, text, font_size, x, y):

    font = pygame.font.Font(font_name, font_size)
    text_surface = font.render(text, True, entity_color)
    text_rect = text_surface.get_rect()
    text_rect.midtop = (x, y)
    surf.blit(text_surface, text_rect)
def doRectsOverlap(rect1, rect2): #checks to see if the first rect collides coordinates with the second
    for a, b in [(rect1, rect2), (rect2, rect1)]:
        # Check if a's corners are inside b
        if ((isPointInsideRect(a.left, a.top, b)) or
            (isPointInsideRect(a.left, a.bottom, b)) or
            (isPointInsideRect(a.right, a.top, b)) or
            (isPointInsideRect(a.right, a.bottom, b))):
            return True

    return False

def isPointInsideRect(x, y, rect): #checks to see if the point is inside the rect
    if (x > rect.left) and (x < rect.right) and (y > rect.top) and (y < rect.bottom):
        return True
    else:
        return False

class Entity(pygame.sprite.Sprite):
    """Inherited by any object in the game."""

    def __init__(self, x, y, width, height):
        pygame.sprite.Sprite.__init__(self)

        self.x = x
        self.y = y
        self.width = width
        self.height = height

        # This makes a rectangle around the entity, used for anything
        # from collision to moving around.
        self.rect = pygame.Rect(self.x, self.y, self.width, self.height)


class Paddle(Entity):
    """
    Player controlled or AI controlled, main interaction with
    the game
    """

    def __init__(self, x, y, width, height):
        super(Paddle, self).__init__(x, y, width, height)

        self.image = pygame.Surface([self.width, self.height])
        self.image.fill(entity_color)
class Player(Paddle):
    """The player controlled Paddle"""

    def __init__(self, x, y, width, height):
        super(Player, self).__init__(x, y, width, height)
        # How many pixels the Player Paddle should move on a given frame.
        self.y_change = 0
        # How many pixels the paddle should move each frame a key is pressed.
        self.y_dist = 5
        self.cy=250
    def MoveKeyDown(self, key):

        """Responds to a key-down event and moves accordingly"""
        if (key == pygame.K_UP):
            self.y_change += -self.y_dist
            self.cy+= -self.y_dist
        elif (key == pygame.K_DOWN):
            self.y_change += self.y_dist
            self.cy += self.y_dist

    def MoveKeyUp(self, key):
        """Responds to a key-up event and stops movement accordingly"""
        if (key == pygame.K_UP):
            self.y_change += self.y_dist
            self.cy += self.y_dist
        elif (key == pygame.K_DOWN):
            self.y_change += -self.y_dist
            self.cy += -self.y_dist

    def update(self):
        """
        Moves the paddle while ensuring it stays in bounds
        """
        # Moves it relative to its current location.
        self.rect.move_ip(0, self.y_change)
        # If the paddle moves off the screen, put it back on.
        if self.rect.y < 0:
            self.rect.y = 0
        elif self.rect.y > window_height - self.height:
            self.rect.y = window_height - self.height
    def changeheight(self,newheight):
        self.height=newheight
        super(Player, self).__init__(self.x, self.rect.y, self.width, self.height)

    def getheight(self):
        return (self.height)
    def gcy(self):
        return self.cy



class Enemy(Paddle):
    """
    AI controlled paddle, simply moves towards the ball
    and nothing else.
    """

    def __init__(self, x, y, width, height):
        super(Enemy, self).__init__(x, y, width, height)

        self.y_change = .5

    def update(self):
        """
        Moves the Paddle while ensuring it stays in bounds
        """
        # Moves the Paddle up if the ball is above,
        # and down if below.
        if ball.rect.y < self.rect.y:
            self.rect.y -= self.y_change
        elif ball.rect.y > self.rect.y:
            self.rect.y += self.y_change

        # The paddle can never go above the window since it follows
        # the ball, but this keeps it from going under.
        if self.rect.y + self.height > window_height:
            self.rect.y = window_height - self.height


class Ball(Entity):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.image = pygame.Surface((20, 20))
        self.image.fill(entity_color)
        self.rect = self.image.get_rect()

        # Movement variables
        self.rect.x = 400
        self.rect.y = 250
        self.speedx = -2
        self.speedy = -2.25

        self.opponent_scored = False
        self.player_scored = False

    def update(self):
        global paused
        global score
        global opponent_score
        global hitnumber
        global bx
        global by
        global nbx
        global nby
        self.rect.x += self.speedx
        self.rect.y += self.speedy



        if self.rect.y > 480:
            self.speedy *= -1
        if self.rect.y < 0:
            self.speedy *= -1

        if self.rect.x <= 0:
            self.rect.y = 250
            self.rect.x = 400
            self.speedx = -2
            self.speedy = -2.25
            bx = 2
            by = 2.25
            nbx = -2
            nby = -2.25
            opponent_score += 1
            player.changeheight(100)
            if(enemy.y_change>.1):
                enemy.y_change -= .1
            hitnumber=0
            self.opponent_scored = True

        if self.rect.x >= 780:
            self.rect.y = 250
            self.rect.x = 400
            self.speedx = -2
            self.speedy = 2.25
            bx = 2
            by = 2.25
            nbx = -2
            nby = -2.25
            score += 1
            enemy.y_change+=.5
            hitnumber = 0
            self.player_scored = True
    def change_speed(self, nspeedx,nspeedy):
        self.speedx=nspeedx
        self.speedy=nspeedy


pygame.init()

window_width = 800
window_height = 500
screen = pygame.display.set_mode((window_width, window_height))

pygame.display.set_caption("Pong")

clock = pygame.time.Clock()

ball = Ball()
player = Player(10, window_height / 2, 20, 100)
enemy = Enemy(window_width - 30, window_height / 2, 20, 100)

all_sprites_list = pygame.sprite.Group()
players = pygame.sprite.Group()
playerone = pygame.sprite.Group()
playerone.add(player)
game_ball = pygame.sprite.Group()
all_sprites_list.add(ball)
all_sprites_list.add(player)
all_sprites_list.add(enemy)
players.add(player)
players.add(enemy)
game_ball.add(ball)

all_sprites_list.update()

opponent_score = 0
score = 0
last_hit = pygame.time.get_ticks()
hit_delay = 100
hitnumber = 0
bx=2
by=2.25
nbx=-2
nby=-2.25

done = True
while True:
    screen.fill(background)

    if opponent_score==3:



        draw_text(screen, "You Lost!", 32, 400, 10)
        draw_text(screen, "Your score: "+str(score), 32, 400, 45)
        draw_text(screen,"Top Ten High Scores",25,400,80)

        infile = open("highscore.txt", "r")
        l=[]
        aline = infile.readline()

        while aline:

            l.append(aline)
            aline = infile.readline()
        l.append(str(score)+'\n')
        l.sort(reverse=True)
        print(l)
        l=l[:10]

        infile.close()
        outfile = open("highscore.txt", "w")

        cn = 105
        hn=1
        for i in l:

            outfile.write(str(i))
            draw_text(screen, str(hn)+". "+i.replace('\n',''), 25, 400, cn)
            cn+=25
            hn+=1
        outfile.close()
        pygame.display.flip()
        time.sleep(5)
        sys.exit()
    while not done:
        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                done = False


                    # -----Paused Event-----
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        elif event.type == pygame.KEYDOWN:
            player.MoveKeyDown(event.key)
        elif event.type == pygame.KEYUP:
            player.MoveKeyUp(event.key)



            # --------update-------
    all_sprites_list.update()

    # -----Logic-----
    hits = pygame.sprite.groupcollide(game_ball,players, False, False)

    # fixing jitter
    now = pygame.time.get_ticks()

    for balls in hits:

        if now - last_hit > hit_delay:
            last_hit = now
            if (player.getheight() > 40 and hitnumber%2==0):
                ch = player.getheight()  # current height
                player.changeheight(ch - 5)



                all_sprites_list.update()
            if ball.rect.x > 400:
                ball.speedx += 1
                ball.speedx *= -1

            elif ball.rect.x < 400:
                ball.speedx *= -1
            if doRectsOverlap(ball.rect, player.rect):

                bx += .25
                by += .25
                nbx -= .25
                nby -= .25
                if ball.rect.y < (player.rect.y+(player.getheight()/2)):
                    ball.change_speed(bx, nby)

                elif ball.rect.y >= (player.rect.y + (player.getheight()/2)):
                    ball.change_speed(bx, by)

            elif doRectsOverlap(ball.rect,enemy.rect):
                bx += .25
                by += .25
                nbx -= .25
                nby -= .25
                if ball.rect.y < (enemy.rect.y + 50):
                    ball.change_speed(nbx,nby)

                elif ball.rect.y >= (enemy.rect.y + 50):
                    ball.change_speed(nbx,by)

            hitnumber+=1


    all_sprites_list.update()


    all_sprites_list.draw(screen)
    draw_text(screen, str(opponent_score), 32, 760, 10)
    draw_text(screen, str(score), 32, 40, 10)

    pygame.display.flip()

    clock.tick(60)